package org.example;

public class Singleylinkedlist {
    Node head;

    public void insert(int data){
        Node newnode = new Node();
        newnode.data = data;
        newnode.next = null;

        if(head == null){
            head = newnode;
            return;
        }else{

            Node current = head;
            while(current.next != null){
                current = current.next;
            }
            current = newnode;
        }
    }
    // Adding element at first

    public void insertfirstelement(int value){
        Node newnode = new Node();
        newnode.next = head;
        head = newnode;
    }

    // Inserting by index location

    public void insertinindex(int index, int value){

        Node newnode = new Node();
        Node current = head;

        if(index == 0){
            insertfirstelement(value);
        }else{
            for(int i=0; i<index-1; i++){
                current = current.next;
            }
            newnode.next = current.next;
            current.next = newnode;
        }
    }

    // deleting an element

    public void deleteAt(int index){
        Node newnode = new Node();
        Node newnode1 = null;
        if(index == 0)
            head = head.next;
        else{

            Node current = head;
            for(int i=0; i<index-1; i++){
                current = current.next;
            }
            newnode1 = current.next;
            current.next = newnode1.next;
        }
    }

    // To display the list

    public void show(){

        Node current = head;
        while(current.next != null){
            System.out.print("Newnode: "+ current.data);
            current = current.next;
        }
        System.out.print(current.data);
    }
}
