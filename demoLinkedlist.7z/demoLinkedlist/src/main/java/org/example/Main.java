package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Singleylinkedlist list = new Singleylinkedlist();

        list.insert(55);;
        list.insert(42);
        list.show();
        list.insertinindex(1, 15);
        list.insertfirstelement(20);
        list.deleteAt(1);
    }
}