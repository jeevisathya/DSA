package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Circularlinkedlist list = new Circularlinkedlist();
        list.insert(23);
        list.insert(24);
        list.insertatfirst(25);
        list.show();
        list.insertatend(26);
        list.show();
        list.insertatindex(1, 27);
        list.show();
        list.deleteatfirst();
        list.show();
        list.deleteatindex(1);
        list.show();
        list.deleteatend();
        list.show();
    }
}