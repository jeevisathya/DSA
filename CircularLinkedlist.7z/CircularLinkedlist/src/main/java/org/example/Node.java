package org.example;

public class Node {

    int data;
    Node next;
    Node tail;
    Node head;
}
