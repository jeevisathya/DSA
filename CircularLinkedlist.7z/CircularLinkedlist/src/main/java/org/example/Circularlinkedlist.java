package org.example;

public class Circularlinkedlist {
    Node head;
    Node tail;

    public void insert(int data) {
        Node newnode = new Node();
        newnode.data = data;
        newnode.next = null;
        newnode.tail = null;

        if (head == null) {
            head = newnode;
            tail = newnode;
            newnode.next = head;
        } else {
            newnode.next = head;
            tail.next = newnode;
            tail = newnode;
        }
    }
    public void insertatfirst(int data) {
        if (head == null) {
            insert(data);
        } else {
            Node newnode = new Node();
            newnode.data = data;
            newnode.tail = null;
            newnode.next = null;

            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newnode;
            newnode.next = head;
            head = newnode;
            System.out.println("Newnode inserted as a first node: ");
        }
    }
    public void insertatend(int data) {
        if (head == null) {
            insert(data);
        } else {
            Node newnode = new Node();
            newnode.data = data;
            newnode.tail = null;
            newnode.next = null;
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            newnode.next = head;
            current.next = newnode;
            tail = newnode;
            System.out.println("Newnode inserted as a last node: ");
        }
    }
    public void insertatindex(int index, int data) {
        Node newnode = new Node();
        newnode.tail = null;
        newnode.data = data;
        newnode.next = null;
        Node current = head;
        int currentposition = 0;
        while (currentposition < index) {
            currentposition++;
        }
        newnode.next = current.next;
        current.next = newnode;
        System.out.println("Newnode inserted in the index location: ");
    }
    public void deleteatfirst() {
        if (head == null)
            return;
        if (head == tail)
            head = tail = null;
        else {
            head = head.next;
            tail.next = head;
        }
        System.out.println("Node deleted at the first: ");
    }
    public void deleteatend() {
        Node prev =null;
        if (head == null)
            return;
        if (head == tail)
            head = tail = null;
        else {
            Node current = head;
            while (current.next != head) {
                prev = current;
                current = current.next;
            }
            prev.next=head;
            tail=prev;
            System.out.println("Node deleted at the end: ");
        }
    }

    public void deleteatindex(int index){
        if (head == null)
            return;
        if (head == tail)
            head = tail = null;
        else {
            Node current = head;
            int currentposition = 0;
            while (current.next != head && currentposition < index - 1) {
                currentposition++;
                current = current.next;
            }
            current.next=current.next.next;
            System.out.println("Node deleted at the index location: ");
        }
    }

    public void show() {
        Node current = head;
        while (current.next != head) {
            System.out.println("Newnode: " + current.data);
            current = current.next;
        }
        System.out.println("Newnode: " + current.data);
    }
}
