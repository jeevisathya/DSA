package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Doublylinkedlist list = new Doublylinkedlist();
        list.insert(54);
        list.insert(56);
        list.show();
        list.insertatend(10);
        list.show();
        list.insertatfirst(13);
        list.show();
        list.insertatposition(0,12);
        list.show();
        list.deleateatindex(1);
        list.show();
        list.deleteatfirst();
        list.show();
        list.deleteatend();
        list.show();
    }
}