package org.example;

public class Doublylinkedlist {
    Node head;
    Node prev;

    public void insert(int data){

        Node newnode = new Node();
        newnode.data = data;
        newnode.next = null;
        newnode.prev = null;

        if(head == null){
            head = newnode;
            prev = newnode;
        }else{
            Node current = head;

            current.next = newnode;
            newnode.prev = current;
            current = newnode;
        }
    }

    // Insert data in beginning
    public void insertatfirst(int data){
        Node newnode = new Node();
        newnode.data = data;
        newnode.next = null;
        newnode.prev = null;

        if(head==null){
            head = newnode;
            prev = newnode;
        }
        else{
            newnode.next = head;
            head.prev = newnode;
            head = newnode;
            System.out.println("Newnode after added in the first location::");
        }
    }
    public  void insertatposition(int index, int data){
        Node newnode = new Node();
        newnode.data = data;
        newnode.next = null;
        newnode.prev = null;
        Node current = head;

        if(current == null){
            insert(data);
        }else if(index==0){
            insertatfirst(data);
        }else{
            int currentposition = 0;
            while(current != null && currentposition < index){
                current = current.next;
                currentposition++;
            }
            newnode.next = current;   // setting up the newnode
            newnode.prev = current.prev;
            current.prev.next = newnode;
            current.prev = newnode; // inserting in the middle
            System.out.println("Newnode after added in the mid location:");
        }
    }

    //Inserting at the last location
    public void insertatend(int data){
        Node newnode = new Node();
        newnode.data=data;
        newnode.next=null;
        newnode.prev=null;

        Node current = head;
        while(current.next != null){
            current = current.next;
        }
        newnode.prev = current;
        newnode.next = null;
        current.next = newnode;
        System.out.println("Newnode after added io the end location:");
    }

    // Deleted the node based on their index
    public void deleateatindex(int index){
        Node current = head;

        if (head == null) {
            System.out.println("List is empty. Nothing to delete.");
            return;
        }else {
            int currentposition = 0;
            while (current != null && currentposition < index) {
                current = current.next;
                currentposition++;
            }
            current.prev.next = current.next;
            current.next.prev = current.prev;
            current.next = null;
            current.prev = null;
            System.out.println("Deleted the node at the index location:");
        }
    }

    // Deleted the first node
    public void deleteatfirst(){
        if (head == null) {
            System.out.println("List is empty. Nothing to delete.");
            return;
        }else {
            head = head.next;
            head.prev = null;
            System.out.println("Deleted the first node:");
        }
    }

    // Deleted the last node
    public void deleteatend(){
        Node current = head;
        if (head == null) {
            System.out.println("List is empty. Nothing to delete.");
            return;
        }else if (head.next == null) {
            // Only one node in the list
            head = null;
            System.out.println("Deleted the last node.");
            return;
        }else {
            while (current.next != null) {
                current = current.next;
            }
            current.prev.next = null;
            current.prev = null;
            System.out.println("Deleted the last node:");
        }
    }

    public void show(){
        Node current = head;
        while(current != null) {
            System.out.println("Newnode: " + current.data);
            current = current.next;
        }
    }
}
